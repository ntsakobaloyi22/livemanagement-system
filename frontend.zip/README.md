# Login & Registration UI Template

A clean, lightweight login/registration page design you can drop into any project. 
Simple HTML/CSS with an image background—ideal for quick onboarding screens or small apps.

## Includes
- Responsive login/register layout
- Minimal CSS styling
- Image assets

## How to use
- Open `index.html` in a browser—or integrate the markup/styles into your app’s auth pages.
