<?php
  $dbConnection = mysqli_connect('localhost', 'root', '', 'onlineLeaveDb');
  
  if ($dbConnection->connect_error) {
    die("Database connection failed: " . $dbConnection->connect_error."<br>");
  }
?>