<?php

require_once("databaseConnection.php");

if(!$dbConnection){
    die("Connection Failed");
}

$sqlQuery = "SELECT * FROM users WHERE type='Employee'";
                $query = $dbConnection->query($sqlQuery);

                echo "$query->num_rows";
?>