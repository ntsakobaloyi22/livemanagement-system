# Online Leave Application (PHP & MySQL)

A simple leave management system that lets employees submit leave requests and lets administrators approve or reject them. 
It includes user registration/login, leave application forms, leave history, and basic admin reporting. 
Built with PHP and MySQL, this project is a clean starting point you can deploy or extend for small teams.

## Features
- Employee signup & login
- Submit leave requests with dates and reasons
- Admin dashboard to approve/reject requests
- Personal leave history and global leave history
- Lightweight, no framework required

## Tech
- PHP (procedural)
- MySQL (import `DATABASE FILE/onlineleavedb.sql`)
- HTML/CSS

## Setup
1. Create a MySQL database named `onlineLeaveDb`.
2. Import `DATABASE FILE/onlineleavedb.sql`.
3. Update credentials in `databaseConnection.php` if needed.
4. Place the project in your server’s web root (e.g., `htdocs` or `public_html`).
5. Visit `index.php`.
