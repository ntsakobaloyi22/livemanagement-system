<?php
require_once("databaseConnection.php");
session_start();
                                     
if (isset($_GET['id']))
{
    $id=$_GET['id'];
    $deleteQuery="DELETE FROM users WHERE id=$id"; 
    mysqli_query($dbConnection, $deleteQuery);

    echo "<script>window.location = 'listEmployees.php';</script>";
} else {
    echo "ERROR!";
}

?>